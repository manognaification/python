/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#define begin main
int begin()
{
    int n1,n2;
printf("enter 2 numbers ");
printf("%d",scanf("%d %d",&n1,&n2));
}
